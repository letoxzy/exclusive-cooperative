import { useState, useEffect, useCallback } from "react";
import { useAuth } from "../context/AuthContext";
import request from "../utils/api";
import { getPasswordChecks, isStrongPassword } from "../utils/passwordPolicy";

import "../styles/admin.css";
import "../styles/admin-components.css";

import {
  FaUsers,
  FaHandHoldingDollar,
  FaClock,
  FaBell,
  FaTrash,
} from "react-icons/fa6";

import AdminSidebar from "../components/admin/AdminSidebar";
import MembershipModal from "../components/admin/MembershipModal";
import AddExistingMemberModal from "../components/admin/AddExistingMemberModal";
import AdminNotifications from "../components/admin/AdminNotifications";
import AdminActionModal from "../components/admin/AdminActionModal";
import GalleryManagement from "../components/admin/GalleryManagement";
import KycReviewModal from "../components/admin/KycReviewModal";

const statusLabel = (value) =>
  String(value || "not started")
    .replaceAll("_", " ")
    .replace(/\b\w/g, (letter) => letter.toUpperCase());

function AdminDashboard() {
  const { user, logout, refreshUser } = useAuth();

  const [activeSection, setActiveSection] = useState("overview");

  const [requests, setRequests] = useState([]);
  const [members, setMembers] = useState([]);
  const [applications, setApplications] = useState([]);
  const [loans, setLoans] = useState([]);
  const [loanEligibilityApplications, setLoanEligibilityApplications] =
    useState([]);
  const [loanRepayments, setLoanRepayments] = useState([]);
  const [dividends, setDividends] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [securityAlerts, setSecurityAlerts] = useState([]);
  const [selectedDividendId, setSelectedDividendId] = useState(null);
  const [selectedDividend, setSelectedDividend] = useState(null);
  const [dividendEntries, setDividendEntries] = useState([]);
  const [showCreateDividendForm, setShowCreateDividendForm] = useState(false);
  const [dividendForm, setDividendForm] = useState({
    financialYear: new Date().getFullYear(),
    pool: "",
    periodStartDate: "",
    periodEndDate: "",
    distributionDate: "",
  });
  const [dividendActionLoading, setDividendActionLoading] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [cooperativeSettings, setCooperativeSettings] = useState({
    loanMultiplier: 2,
    repaymentAccountName: "Exclusive Cooperative Multipurpose Society Limited",
    repaymentBank: "UBA",
    repaymentAccountNumber: "0123456789",
  });
  const [savingCooperativeSettings, setSavingCooperativeSettings] =
    useState(false);
  const [cooperativeSettingsMessage, setCooperativeSettingsMessage] =
    useState(null);

  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [readNotificationIds, setReadNotificationIds] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem("adminReadNotifications") || "[]");
    } catch {
      return [];
    }
  });

  const [viewingApplication, setViewingApplication] = useState(null);
  const [openInEditMode, setOpenInEditMode] = useState(false);
  const [reviewEligibilityId, setReviewEligibilityId] = useState(null);
  const [eligibilityFilter, setEligibilityFilter] = useState("review");
  const [showAddExistingMember, setShowAddExistingMember] = useState(false);
  const [deletingMemberId, setDeletingMemberId] = useState(null);
  const [actionModal, setActionModal] = useState(null);

  // Admin list search + filters
  const [memberSearch, setMemberSearch] = useState("");
  const [memberFilter, setMemberFilter] = useState("all");
  const [applicationSearch, setApplicationSearch] = useState("");
  const [applicationFilter, setApplicationFilter] = useState("all");
  const [actionModalLoading, setActionModalLoading] = useState(false);

  /* ================================
     LOAD DATA
  ================================= */

  const loadRequests = useCallback(async () => {
    const data = await request("/admin/savings-requests", {
      token: user.token,
    });

    setRequests(data);
  }, [user.token]);

  const loadMembers = useCallback(async () => {
    const data = await request("/admin/users", {
      token: user.token,
    });

    setMembers(data);
  }, [user.token]);

  const loadSecurityAlerts = useCallback(async () => {
    try {
      const data = await request("/admin/security-alerts", {
        token: user.token,
      });
      setSecurityAlerts(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error("Security alerts load error:", err);
    }
  }, [user.token]);

  const updateNotifications = useCallback((applications) => {
    const newNotifications = applications
      .filter((application) => application.status === "pending")
      .map((application) => ({
        id: application._id,
        type: "membership",
        title: "New Membership Application",
        body: `${application.user?.fullName || "A member"} submitted a membership application.`,
        createdAt:
          application.createdAt ||
          application.submittedDate ||
          new Date().toISOString(),
        application,
      }));

    setNotifications(newNotifications);
  }, []);

  const loadApplications = useCallback(async () => {
    const data = await request("/admin/membership", {
      token: user.token,
    });

    setApplications(data);
    updateNotifications(data);
  }, [user.token, updateNotifications]);

  // Automatically check for new membership applications
  useEffect(() => {
    if (!user?.token) return;

    const checkForNewApplications = async () => {
      try {
        await loadApplications();
      } catch (err) {
        console.error("Notification polling error:", err);
      }
    };

    // Check immediately, then every 10 seconds.
    checkForNewApplications();

    const interval = setInterval(checkForNewApplications, 10000);

    return () => clearInterval(interval);
  }, [user?.token, loadApplications]);

  const loadLoans = useCallback(async () => {
    const data = await request("/admin/loans", {
      token: user.token,
    });

    setLoans(data);
  }, [user.token]);

  const loadLoanEligibilityApplications = useCallback(async () => {
    const data = await request("/admin/loan-eligibility-applications", {
      token: user.token,
    });

    setLoanEligibilityApplications(data);
  }, [user.token]);

  // Keep the Full Loan Applications queue live so a newly completed
  // identity verification appears in the admin notification bell without
  // requiring the administrator to refresh the page.
  useEffect(() => {
    if (!user?.token) return;

    const refreshLoanEligibilityQueue = () => {
      loadLoanEligibilityApplications().catch((err) => {
        console.error("Full loan application notification polling error:", err);
      });
    };

    refreshLoanEligibilityQueue();
    const interval = setInterval(refreshLoanEligibilityQueue, 10000);

    return () => clearInterval(interval);
  }, [user?.token, loadLoanEligibilityApplications]);

  const loadDividends = useCallback(async () => {
    const data = await request("/admin/dividends", {
      token: user.token,
    });

    setDividends(data);
  }, [user.token]);

  const loadLoanRepayments = useCallback(async () => {
    const data = await request("/admin/loan-repayments", {
      token: user.token,
    });

    setLoanRepayments(data);
  }, [user.token]);

  const loadWithdrawals = useCallback(async () => {
    const data = await request("/admin/withdrawals", {
      token: user.token,
    });

    setWithdrawals(data);
  }, [user.token]);
  const loadCooperativeSettings = useCallback(async () => {
    const data = await request("/admin/cooperative-settings", {
      token: user.token,
    });

    setCooperativeSettings({
      loanMultiplier: Number(data?.loanMultiplier ?? 2),
      repaymentAccountName:
        data?.repaymentAccountName ||
        "Exclusive Cooperative Multipurpose Society Limited",
      repaymentBank: data?.repaymentBank || "UBA",
      repaymentAccountNumber: data?.repaymentAccountNumber || "0123456789",
    });
  }, [user.token]);

  const saveCooperativeSettings = async (event) => {
    event.preventDefault();
    setCooperativeSettingsMessage(null);

    const multiplier = Number(cooperativeSettings.loanMultiplier);
    const accountNumber = String(
      cooperativeSettings.repaymentAccountNumber || "",
    ).trim();

    if (!Number.isFinite(multiplier) || multiplier <= 0 || multiplier > 2) {
      setCooperativeSettingsMessage({
        type: "error",
        text: "Loan eligibility multiplier must be greater than 0 and cannot exceed 2×.",
      });
      return;
    }

    if (!/^[0-9]{10}$/.test(accountNumber)) {
      setCooperativeSettingsMessage({
        type: "error",
        text: "Repayment account number must be exactly 10 digits.",
      });
      return;
    }

    if (
      !String(cooperativeSettings.repaymentAccountName || "").trim() ||
      !String(cooperativeSettings.repaymentBank || "").trim()
    ) {
      setCooperativeSettingsMessage({
        type: "error",
        text: "Repayment account name and bank are required.",
      });
      return;
    }

    setSavingCooperativeSettings(true);

    try {
      const saved = await request("/admin/cooperative-settings", {
        method: "PUT",
        token: user.token,
        body: {
          loanMultiplier: multiplier,
          repaymentAccountName: cooperativeSettings.repaymentAccountName.trim(),
          repaymentBank: cooperativeSettings.repaymentBank.trim(),
          repaymentAccountNumber: accountNumber,
        },
      });

      setCooperativeSettings({
        loanMultiplier: Number(saved.loanMultiplier ?? multiplier),
        repaymentAccountName: saved.repaymentAccountName,
        repaymentBank: saved.repaymentBank,
        repaymentAccountNumber: saved.repaymentAccountNumber,
      });

      setCooperativeSettingsMessage({
        type: "success",
        text: "Cooperative configuration updated successfully.",
      });
    } catch (err) {
      setCooperativeSettingsMessage({
        type: "error",
        text: err.message,
      });
    } finally {
      setSavingCooperativeSettings(false);
    }
  };

  /* ================================
     LOAD DATA WHEN SECTION CHANGES
  ================================= */

  useEffect(() => {
    if (activeSection === "overview") {
      Promise.all([
        loadRequests(),
        loadMembers(),
        loadApplications(),
        loadLoans(),
        loadLoanEligibilityApplications(),
        loadLoanRepayments(),
        loadWithdrawals(),
        loadSecurityAlerts(),
        loadCooperativeSettings(),
      ]).catch((err) => {
        setError(err.message);
      });

      return;
    }

    setError("");
    setLoading(true);

    let loader;

    if (activeSection === "savings") {
      loader = loadRequests;
    } else if (activeSection === "members") {
      loader = async () => {
        await Promise.all([loadMembers(), loadSecurityAlerts()]);
      };
    } else if (activeSection === "membership") {
      loader = loadApplications;
    } else if (activeSection === "loan-requests") {
      loader = loadLoans;
    } else if (activeSection === "loan-eligibility") {
      loader = loadLoanEligibilityApplications;
    } else if (activeSection === "repayments") {
      loader = loadLoanRepayments;
    } else if (activeSection === "dividends") {
      loader = loadDividends;
    } else if (activeSection === "withdrawals") {
      loader = loadWithdrawals;
    } else if (activeSection === "settings") {
      loader = loadCooperativeSettings;
    }

    if (!loader) {
      setLoading(false);
      return;
    }

    loader()
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, [
    activeSection,
    loadRequests,
    loadMembers,
    loadApplications,
    loadLoans,
    loadLoanEligibilityApplications,
    loadLoanRepayments,
    loadDividends,
    loadWithdrawals,
    loadSecurityAlerts,
    loadCooperativeSettings,
  ]);

  /* ================================
     REPAYMENT QUEUE SYNC
  ================================= */

  useEffect(() => {
    if (!user?.token || activeSection !== "repayments") return;

    const refreshRepaymentQueue = () => {
      loadLoanRepayments().catch((err) => {
        console.error("Repayment queue refresh error:", err);
      });
    };

    const interval = window.setInterval(refreshRepaymentQueue, 10000);

    return () => window.clearInterval(interval);
  }, [user?.token, activeSection, loadLoanRepayments]);

  /* ================================
     SAVINGS REQUEST ACTION
  ================================= */

  const handleRequestAction = async (id, action) => {
    try {
      setError("");

      await request(`/admin/savings-requests/${id}`, {
        method: "PATCH",
        token: user.token,
        body: { action },
      });

      await loadRequests();
    } catch (err) {
      setError(err.message);
    }
  };

  /* ================================
     EXISTING MEMBER ACCOUNT
  ================================= */

  const handleCreateExistingMember = async (memberData) => {
    try {
      setError("");

      const formData = new FormData();

      Object.entries(memberData).forEach(([key, value]) => {
        if (value === null || value === undefined || value === "") return;

        if (value instanceof File) {
          formData.append(key, value);
        } else {
          formData.append(key, value);
        }
      });

      const result = await request("/admin/members/existing", {
        method: "POST",
        token: user.token,
        body: formData,
        isFormData: true,
      });

      await loadMembers();
      return result;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  /* ================================
     MEMBER SHAREHOLDING
  ================================= */

  const handleShareholdingUpdate = (member) => {
    if (!member?._id || member.role === "admin") return;

    setActionModal({
      type: "shareholding",
      title: "Update Shareholding",
      description: `Update the total shareholding value for ${member.fullName || "this member"}.`,
      member,
      value: String(Number(member.shareholding || 0)),
      label: "Shareholding Amount",
      placeholder: "Enter amount",
      inputType: "number",
      confirmText: "Update Shareholding",
    });
  };

  /* ================================
     DELETE MEMBER ACCOUNT
  ================================= */

  const handleDeleteMember = (member) => {
    if (!member?._id || member.role === "admin") return;

    setActionModal({
      type: "delete-member",
      title: "Delete Member Account",
      description: `Delete the account for ${member.fullName || member.email}? This will remove the member login account and membership record. This action cannot be undone.`,
      member,
      confirmText: "Delete Account",
      danger: true,
    });
  };

  /* ================================
     MEMBERSHIP ACTION
  ================================= */

  const handleApplicationStatus = async (id, status) => {
    try {
      setError("");

      const updated = await request(`/admin/membership/${id}`, {
        method: "PATCH",
        token: user.token,
        body: { status },
      });

      await loadApplications();
      // Keep the open modal (if any) showing the fresh status immediately.
      setViewingApplication((prev) =>
        prev && prev._id === id ? updated : prev,
      );
    } catch (err) {
      setError(err.message);
    }
  };

  const handleApplicationSave = async (id, updatedFields) => {
    const updated = await request(`/admin/membership/${id}`, {
      method: "PATCH",
      token: user.token,
      body: updatedFields,
    });

    await loadApplications();
    setViewingApplication(updated);
  };

  /* ================================
   LOAN ACTION
================================ */

  const handleLoanAction = async (id, action) => {
    if (action === "reject") {
      setActionModal({
        type: "reject-loan",
        title: "Reject Loan Application",
        description:
          "Please provide a reason for rejecting this loan application.",
        id,
        value: "",
        label: "Rejection Reason",
        placeholder: "Enter the reason for rejection",
        inputType: "textarea",
        confirmText: "Reject Loan",
        danger: true,
      });
      return;
    }

    try {
      setError("");

      await request(`/admin/loans/${id}`, {
        method: "PATCH",
        token: user.token,
        body: {
          action,
          rejectionReason: "",
        },
      });

      await loadLoans();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDisburseLoan = async (id) => {
    try {
      setError("");

      await request(`/admin/loans/${id}/disburse`, {
        method: "PATCH",
        token: user.token,
      });

      await loadLoans();
    } catch (err) {
      setError(err.message);
    }
  };

  /* ================================
     PROFESSIONAL ACTION MODAL SUBMIT
  ================================= */

  const handleActionModalSubmit = async (value) => {
    if (!actionModal) return;

    try {
      setError("");
      setActionModalLoading(true);

      if (actionModal.type === "shareholding") {
        const amount = Number(value);

        if (!Number.isFinite(amount) || amount < 0) {
          setError("Shareholding must be a valid amount of 0 or more.");
          return;
        }

        const updated = await request(
          `/admin/users/${actionModal.member._id}/shareholding`,
          {
            method: "PATCH",
            token: user.token,
            body: { shareholding: amount },
          },
        );

        setMembers((prev) =>
          prev.map((item) => (item._id === updated._id ? updated : item)),
        );
      }

      if (
        actionModal.type === "block-member" ||
        actionModal.type === "unblock-member"
      ) {
        const blocked = actionModal.type === "block-member";
        const updated = await request(
          `/admin/users/${actionModal.member._id}/block`,
          {
            method: "PATCH",
            token: user.token,
            body: {
              blocked,
              reason: String(
                value || "Security review by administrator",
              ).trim(),
            },
          },
        );
        setMembers((prev) =>
          prev.map((item) =>
            item._id === updated._id ? { ...item, ...updated } : item,
          ),
        );
        setActionModal(null);
      }

      if (actionModal.type === "security-unlock") {
        const updated = await request(
          `/admin/users/${actionModal.member._id}/security-unlock`,
          {
            method: "PATCH",
            token: user.token,
          },
        );

        setMembers((prev) =>
          prev.map((item) =>
            item._id === updated._id ? { ...item, ...updated } : item,
          ),
        );
        setActionModal(null);
      }

      if (actionModal.type === "delete-member") {
        setDeletingMemberId(actionModal.member._id);

        await request(`/admin/users/${actionModal.member._id}`, {
          method: "DELETE",
          token: user.token,
        });

        await loadMembers();
      }

      if (actionModal.type === "reject-loan") {
        if (!String(value || "").trim()) {
          setError("Please provide a rejection reason.");
          return;
        }

        await request(`/admin/loans/${actionModal.id}`, {
          method: "PATCH",
          token: user.token,
          body: {
            action: "reject",
            rejectionReason: String(value).trim(),
          },
        });

        await loadLoans();
      }

      setActionModal(null);
    } catch (err) {
      setError(err.message);
    } finally {
      setActionModalLoading(false);
      setDeletingMemberId(null);
    }
  };

  /* ================================
   DIVIDEND ACTIONS
================================ */

  const openDividendDetail = async (id) => {
    try {
      setError("");
      setDividendActionLoading(true);
      setSelectedDividendId(id);

      const data = await request(`/admin/dividends/${id}`, {
        token: user.token,
      });

      setSelectedDividend(data.distribution);
      setDividendEntries(data.entries);
    } catch (err) {
      setError(err.message);
    } finally {
      setDividendActionLoading(false);
    }
  };

  const closeDividendDetail = () => {
    setSelectedDividendId(null);
    setSelectedDividend(null);
    setDividendEntries([]);
  };

  const handleCreateDividend = async (e) => {
    e.preventDefault();

    try {
      setError("");
      setDividendActionLoading(true);

      await request("/admin/dividends", {
        method: "POST",
        token: user.token,
        body: {
          financialYear: Number(dividendForm.financialYear),
          pool: Number(dividendForm.pool),
          periodStartDate: dividendForm.periodStartDate,
          periodEndDate: dividendForm.periodEndDate,
          distributionDate: dividendForm.distributionDate,
        },
      });

      setShowCreateDividendForm(false);
      setDividendForm({
        financialYear: new Date().getFullYear(),
        pool: "",
        periodStartDate: "",
        periodEndDate: "",
        distributionDate: "",
      });

      await loadDividends();
    } catch (err) {
      setError(err.message);
    } finally {
      setDividendActionLoading(false);
    }
  };

  const handleCalculateDividends = async (id) => {
    try {
      setError("");
      setDividendActionLoading(true);

      const data = await request(`/admin/dividends/${id}/calculate`, {
        method: "POST",
        token: user.token,
      });

      setSelectedDividend(data.distribution);
      setDividendEntries(data.entries);

      await loadDividends();
    } catch (err) {
      setError(err.message);
    } finally {
      setDividendActionLoading(false);
    }
  };

  const handleMarkEntryPaid = async (distributionId, entryId) => {
    try {
      setError("");

      await request(`/admin/dividends/${distributionId}/entries/${entryId}`, {
        method: "PATCH",
        token: user.token,
      });

      await openDividendDetail(distributionId);
      await loadDividends();
    } catch (err) {
      setError(err.message);
    }
  };

  const handleMarkAllDividendsPaid = async (id) => {
    try {
      setError("");
      setDividendActionLoading(true);

      const data = await request(`/admin/dividends/${id}/pay-all`, {
        method: "PATCH",
        token: user.token,
      });

      setSelectedDividend(data.distribution);
      setDividendEntries(data.entries);

      await loadDividends();
    } catch (err) {
      setError(err.message);
    } finally {
      setDividendActionLoading(false);
    }
  };

  /* ================================
   LOAN REPAYMENT ACTION
================================ */

  const handleRepaymentAction = async (id, action) => {
    try {
      setError("");

      await request(`/admin/loan-repayments/${id}`, {
        method: "PATCH",
        token: user.token,
        body: { action },
      });

      // Refresh both the repayment queue and loan records immediately.
      // This keeps the admin dashboard's repayment status, amount paid,
      // outstanding balance, and loan status in sync after confirmation.
      await Promise.all([loadLoanRepayments(), loadLoans()]);
    } catch (err) {
      setError(err.message);
    }
  };

  /* ================================
     DASHBOARD STATISTICS
  ================================= */

  const totalSavings = members.reduce(
    (total, member) => total + Number(member.savingsBalance || 0),
    0,
  );

  const pendingSavingsRequests = requests.filter(
    (requestItem) => requestItem.status === "pending",
  ).length;

  const pendingApplications = applications.filter(
    (application) => application.status === "pending",
  ).length;

  const pendingRepayments = loanRepayments.filter(
    (repayment) => repayment.status === "pending",
  ).length;

  const totalLoanEligibility = members.reduce(
    (total, member) => total + Number(member.savingsBalance || 0) * 2,
    0,
  );

  /* ================================
     RENDER OVERVIEW
  ================================= */

  const renderOverview = () => {
    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Dashboard</p>
            <h1>Overview</h1>
            <p className="admin-subtitle">
              Here's what's happening with your cooperative today.
            </p>
          </div>
        </div>

        <div className="admin-stat-grid">
          <div className="admin-stat-card">
            <div className="admin-stat-icon savings-icon">₦</div>

            <div>
              <span>Total Savings</span>
              <strong>₦{totalSavings.toLocaleString()}</strong>
            </div>
          </div>

          <div className="admin-stat-card">
            <div className="admin-stat-icon members-icon">
              <FaUsers />
            </div>

            <div>
              <span>Total Members</span>
              <strong>{members.length}</strong>
            </div>
          </div>

          <div className="admin-stat-card">
            <div className="admin-stat-icon loan-icon">
              <FaHandHoldingDollar />
            </div>

            <div>
              <span>Loan Eligibility</span>
              <strong>₦{totalLoanEligibility.toLocaleString()}</strong>
            </div>
          </div>

          <div className="admin-stat-card">
            <div className="admin-stat-icon pending-icon">
              <FaClock />
            </div>

            <div>
              <span>Pending Requests</span>
              <strong>
                {pendingSavingsRequests +
                  pendingApplications +
                  pendingRepayments}
              </strong>
            </div>
          </div>
        </div>

        <div className="admin-overview-grid">
          <section className="admin-card">
            <div className="admin-card-header">
              <div>
                <p className="eyebrow">Savings</p>
                <h2>Savings Overview</h2>
              </div>

              <button
                className="admin-link-btn"
                onClick={() => setActiveSection("savings")}
              >
                View Requests
              </button>
            </div>

            <div className="admin-big-number">
              ₦{totalSavings.toLocaleString()}
            </div>

            <p className="admin-muted">
              Total savings currently recorded across members.
            </p>

            <div className="admin-progress">
              <div
                className="admin-progress-bar"
                style={{
                  width:
                    members.length > 0
                      ? `${Math.min((totalSavings / 1000000) * 100, 100)}%`
                      : "0%",
                }}
              />
            </div>
          </section>

          <section className="admin-card">
            <div className="admin-card-header">
              <div>
                <p className="eyebrow">Membership</p>
                <h2>Applications</h2>
              </div>

              <button
                className="admin-link-btn"
                onClick={() => setActiveSection("membership")}
              >
                Review
              </button>
            </div>

            <div className="admin-big-number">{pendingApplications}</div>

            <p className="admin-muted">
              Membership applications waiting for review.
            </p>

            <div className="admin-mini-stat">
              <span>Total applications</span>
              <strong>{applications.length}</strong>
            </div>
          </section>
        </div>

        <section className="admin-card admin-recent-section">
          <div className="admin-card-header">
            <div>
              <p className="eyebrow">Activity</p>
              <h2>Recent Savings Requests</h2>
            </div>

            <button
              className="admin-link-btn"
              onClick={() => setActiveSection("savings")}
            >
              View All
            </button>
          </div>

          {requests.length === 0 ? (
            <p className="empty-state">No savings requests yet.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>

                <tbody>
                  {requests.slice(0, 5).map((r) => (
                    <tr key={r._id}>
                      <td>
                        <strong>{r.user?.fullName || "—"}</strong>
                        <br />
                        <span className="muted">{r.user?.email}</span>
                      </td>

                      <td>₦{Number(r.amount || 0).toLocaleString()}</td>

                      <td>{r.method === "paystack" ? "Paystack" : "Manual"}</td>

                      <td>
                        <span className={`status-badge ${r.status}`}>
                          {r.status}
                        </span>
                      </td>

                      <td>{new Date(r.createdAt).toLocaleDateString()}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     SAVINGS REQUESTS
  ================================= */

  const renderSavings = () => {
    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Savings</p>
            <h1>Savings & Deposits</h1>
            <p className="admin-subtitle">
              Review and manage member savings requests.
            </p>
          </div>
        </div>

        <section className="admin-card">
          {requests.length === 0 ? (
            <p className="empty-state">No savings requests yet.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Amount</th>
                    <th>Method</th>
                    <th>Status</th>
                    <th>Requested</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {requests.map((r) => (
                    <tr key={r._id}>
                      <td>
                        {r.user?.fullName || "—"}
                        <br />
                        <span className="muted">{r.user?.email}</span>
                      </td>

                      <td>₦{Number(r.amount || 0).toLocaleString()}</td>

                      <td>{r.method === "paystack" ? "Paystack" : "Manual"}</td>

                      <td>
                        <span className={`status-badge ${r.status}`}>
                          {r.status}
                        </span>
                      </td>

                      <td>{new Date(r.createdAt).toLocaleDateString()}</td>

                      <td className="actions-cell">
                        {r.status === "pending" && (
                          <>
                            <button
                              className="approve-btn"
                              onClick={() =>
                                handleRequestAction(r._id, "approve")
                              }
                            >
                              Approve
                            </button>

                            <button
                              className="reject-btn"
                              onClick={() =>
                                handleRequestAction(r._id, "reject")
                              }
                            >
                              Reject
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
   LOAN REQUESTS
================================ */

  const renderLoans = () => {
    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Loans</p>
            <h1>Loan Requests</h1>
            <p className="admin-subtitle">
              Review, approve, or reject member loan applications.
            </p>
          </div>
        </div>

        <section className="admin-card">
          {loans.length === 0 ? (
            <p className="empty-state">No loan applications yet.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Loan Type</th>
                    <th>Amount</th>
                    <th>Outstanding</th>
                    <th>Savings</th>
                    <th>Eligible</th>
                    <th>Term</th>
                    <th>Status</th>
                    <th>Application Date</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {loans.map((loan) => (
                    <tr key={loan._id}>
                      <td>
                        <strong>{loan.user?.fullName || "—"}</strong>
                        <br />
                        <span className="muted">{loan.user?.email || "—"}</span>
                      </td>

                      <td>
                        <span className="loan-type-badge">{loan.loanType}</span>
                      </td>

                      <td>₦{Number(loan.amount || 0).toLocaleString()}</td>

                      <td>
                        ₦{Number(loan.outstandingBalance || 0).toLocaleString()}
                      </td>

                      <td>
                        ₦
                        {Number(
                          loan.savingsAtApplication || 0,
                        ).toLocaleString()}
                      </td>

                      <td>
                        ₦{Number(loan.eligibleAmount || 0).toLocaleString()}
                      </td>

                      <td>{loan.termMonths} months</td>

                      <td>
                        <span className={`status-badge ${loan.status}`}>
                          {loan.status}
                        </span>
                      </td>

                      <td>
                        {loan.applicationDate
                          ? new Date(loan.applicationDate).toLocaleDateString()
                          : "—"}
                      </td>

                      <td className="actions-cell">
                        {loan.status === "pending" && (
                          <>
                            <button
                              className="approve-btn"
                              onClick={() =>
                                handleLoanAction(loan._id, "approve")
                              }
                            >
                              Approve
                            </button>

                            <button
                              className="reject-btn"
                              onClick={() =>
                                handleLoanAction(loan._id, "reject")
                              }
                            >
                              Reject
                            </button>
                          </>
                        )}

                        {loan.status === "approved" && (
                          <button
                            className="approve-btn"
                            onClick={() => handleDisburseLoan(loan._id)}
                          >
                            Disburse Loan
                          </button>
                        )}

                        {loan.status === "rejected" && (
                          <span className="muted">Rejected</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     LOAN REPAYMENTS
  ================================= */

  const renderRepayments = () => {
    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Repayments</p>
            <h1>Loan Repayments</h1>
            <p className="admin-subtitle">
              Confirm repayments members have recorded against active loans.
            </p>
          </div>
        </div>

        <section className="admin-card">
          {loanRepayments.length === 0 ? (
            <p className="empty-state">No repayment requests yet.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Loan Type</th>
                    <th>Amount</th>
                    <th>Status</th>
                    <th>Receipt</th>
                    <th>Submitted</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {loanRepayments.map((r) => (
                    <tr key={r._id}>
                      <td>
                        {r.user?.fullName || "—"}
                        <br />
                        <span className="muted">{r.user?.email}</span>
                      </td>

                      <td>
                        <span className="loan-type-badge">
                          {r.loan?.loanType || "—"}
                        </span>
                      </td>

                      <td>₦{Number(r.amount || 0).toLocaleString()}</td>

                      <td>
                        <span className={`status-badge ${r.status}`}>
                          {r.status}
                        </span>
                      </td>

                      <td>
                        {r.receiptUrl ? (
                          <a
                            href={r.receiptUrl}
                            target="_blank"
                            rel="noreferrer"
                            className="view-btn"
                          >
                            View Receipt
                          </a>
                        ) : (
                          <span className="muted">No receipt</span>
                        )}
                      </td>

                      <td>{new Date(r.createdAt).toLocaleDateString()}</td>

                      <td className="actions-cell">
                        {r.status === "pending" && (
                          <>
                            <button
                              className="approve-btn"
                              onClick={() =>
                                handleRepaymentAction(r._id, "approve")
                              }
                            >
                              Approve
                            </button>

                            <button
                              className="reject-btn"
                              onClick={() =>
                                handleRepaymentAction(r._id, "reject")
                              }
                            >
                              Reject
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     WITHDRAWALS
  ================================= */

  const handleWithdrawalSync = async (id) => {
    try {
      setError("");

      const result = await request(`/admin/withdrawals/${id}/sync`, {
        method: "POST",
        token: user.token,
      });

      console.log("WITHDRAWAL SYNC RESULT:", result);

      await loadWithdrawals();

      alert(
        `Withdrawal status: ${
          result.status ||
          result.data?.status ||
          result.withdrawal?.status ||
          "unknown"
        }`,
      );
    } catch (err) {
      console.error("WITHDRAWAL SYNC ERROR:", err);

      setError(err.message);

      alert(`Sync failed: ${err.message}`);
    }
  };

  const renderWithdrawals = () => {
    const processing = withdrawals.filter(
      (item) => item.status === "processing",
    );
    const successful = withdrawals.filter((item) => item.status === "success");
    const totalPaid = successful.reduce(
      (sum, item) => sum + Number(item.amount || 0),
      0,
    );

    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Finance</p>
            <h1>Withdrawals</h1>
            <p className="admin-subtitle">
              Monitor member withdrawal requests and transfer status.
              Withdrawals are paid automatically after the member confirms with
              their withdrawal PIN.
            </p>
          </div>
          <button
            type="button"
            className="btn-secondary"
            onClick={loadWithdrawals}
          >
            Refresh
          </button>
        </div>

        <div className="admin-stat-grid">
          <div className="admin-stat-card">
            <div>
              <span>Processing</span>
              <strong>{processing.length}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Paid Withdrawals</span>
              <strong>{successful.length}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Total Paid</span>
              <strong>₦{totalPaid.toLocaleString()}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Total Records</span>
              <strong>{withdrawals.length}</strong>
            </div>
          </div>
        </div>

        <section className="admin-card">
          {withdrawals.length === 0 ? (
            <p className="empty-state">No withdrawal records yet.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Amount</th>
                    <th>Bank</th>
                    <th>Account</th>
                    <th>Status</th>
                    <th>Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {withdrawals.map((item) => (
                    <tr key={item._id}>
                      <td>
                        <strong>{item.user?.fullName || "—"}</strong>
                        <br />
                        <span className="muted">{item.user?.email || "—"}</span>
                      </td>
                      <td>₦{Number(item.amount || 0).toLocaleString()}</td>
                      <td>{item.bankName}</td>
                      <td>
                        {item.accountName}
                        <br />
                        <span className="muted">
                          ····{item.accountNumberLast4}
                        </span>
                      </td>
                      <td>
                        <span className={`status-badge ${item.status}`}>
                          {item.status}
                        </span>
                      </td>
                      <td>
                        {item.createdAt
                          ? new Date(item.createdAt).toLocaleDateString()
                          : "—"}
                      </td>
                      <td className="actions-cell">
                        {item.status === "processing" ? (
                          <button
                            className="view-btn"
                            onClick={() => handleWithdrawalSync(item._id)}
                          >
                            Sync Status
                          </button>
                        ) : (
                          <span className="muted">—</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     DIVIDENDS
  ================================= */

  const renderDividends = () => {
    if (selectedDividendId) {
      return (
        <>
          <div className="admin-page-heading">
            <div>
              <p className="eyebrow">Dividends</p>
              <h1>
                {selectedDividend
                  ? `${selectedDividend.financialYear} Dividend Distribution`
                  : "Dividend Distribution"}
              </h1>
              <p className="admin-subtitle">
                Only interest-bearing members with fully settled loans in the
                selected period are eligible. Shares are based on the loan
                interest actually paid by each member.
              </p>
            </div>

            <button
              type="button"
              className="btn-secondary"
              onClick={closeDividendDetail}
            >
              Back to Dividends
            </button>
          </div>

          {selectedDividend && (
            <section className="admin-card dividend-summary-card">
              <div>
                <strong>Pool</strong>
                <span>₦{Number(selectedDividend.pool).toLocaleString()}</span>
              </div>

              <div>
                <strong>Status</strong>
                <span className={`status-badge ${selectedDividend.status}`}>
                  {selectedDividend.status}
                </span>
              </div>

              <div>
                <strong>Total Eligible Interest</strong>
                <span>
                  ₦
                  {Number(
                    selectedDividend.totalEligibleInterest || 0,
                  ).toLocaleString()}
                </span>
              </div>

              <div>
                <strong>Distribution Date</strong>
                <span>{selectedDividend.distributionDate || "—"}</span>
              </div>

              <div className="dividend-summary-actions">
                {selectedDividend.status !== "completed" && (
                  <button
                    type="button"
                    className="btn-primary"
                    disabled={dividendActionLoading}
                    onClick={() =>
                      handleCalculateDividends(selectedDividend._id)
                    }
                  >
                    {selectedDividend.status === "draft"
                      ? "Calculate Dividends"
                      : "Recalculate Dividends"}
                  </button>
                )}

                {selectedDividend.status === "calculated" &&
                  dividendEntries.length > 0 && (
                    <button
                      type="button"
                      className="approve-btn"
                      disabled={dividendActionLoading}
                      onClick={() =>
                        handleMarkAllDividendsPaid(selectedDividend._id)
                      }
                    >
                      Mark All Paid
                    </button>
                  )}
              </div>
            </section>
          )}

          <section className="admin-card">
            {dividendEntries.length === 0 ? (
              <p className="empty-state">
                {selectedDividend?.status === "draft"
                  ? 'Not calculated yet — click "Calculate Dividends" to generate each member\'s share.'
                  : "No eligible members found for this distribution."}
              </p>
            ) : (
              <div className="admin-table-wrap">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Member</th>
                      <th>Interest Paid</th>
                      <th>Dividend</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>
                    {dividendEntries.map((entry) => (
                      <tr key={entry._id}>
                        <td>
                          <strong>{entry.user?.fullName || "—"}</strong>
                          <br />
                          <span className="muted">
                            {entry.user?.email || "—"}
                          </span>
                        </td>

                        <td>
                          ₦
                          {Number(
                            entry.qualifyingInterest || entry.contribution || 0,
                          ).toLocaleString()}
                        </td>

                        <td>
                          ₦{Number(entry.dividendAmount || 0).toLocaleString()}
                        </td>

                        <td>
                          <span className={`status-badge ${entry.status}`}>
                            {entry.status}
                          </span>
                        </td>

                        <td className="actions-cell">
                          {entry.status === "pending" && (
                            <button
                              className="approve-btn"
                              onClick={() =>
                                handleMarkEntryPaid(
                                  selectedDividendId,
                                  entry._id,
                                )
                              }
                            >
                              Mark Paid
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        </>
      );
    }

    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Dividends</p>
            <h1>Dividends</h1>
            <p className="admin-subtitle">
              Create a dividend pool from the cooperative's accumulated interest
              and distribute it among interest-bearing members based on
              qualifying loan interest actually paid during the selected period.
            </p>
          </div>

          <button
            type="button"
            className="btn-primary"
            onClick={() => setShowCreateDividendForm((prev) => !prev)}
          >
            {showCreateDividendForm ? "Cancel" : "Create Dividend"}
          </button>
        </div>

        {showCreateDividendForm && (
          <section className="admin-card">
            <form
              className="dividend-create-form"
              onSubmit={handleCreateDividend}
            >
              <div className="form-group">
                <label htmlFor="financialYear">Financial Year</label>
                <input
                  id="financialYear"
                  type="number"
                  min="2000"
                  required
                  value={dividendForm.financialYear}
                  onChange={(e) =>
                    setDividendForm((prev) => ({
                      ...prev,
                      financialYear: e.target.value,
                    }))
                  }
                />
              </div>

              <div className="form-group">
                <label htmlFor="pool">
                  Dividend Pool from Accumulated Interest (₦)
                </label>
                <input
                  id="pool"
                  type="number"
                  min="1"
                  required
                  placeholder="e.g. 7000000"
                  value={dividendForm.pool}
                  onChange={(e) =>
                    setDividendForm((prev) => ({
                      ...prev,
                      pool: e.target.value,
                    }))
                  }
                />
              </div>

              <div className="form-group">
                <label htmlFor="periodStartDate">Interest Period Start</label>
                <input
                  id="periodStartDate"
                  type="date"
                  required
                  value={dividendForm.periodStartDate}
                  onChange={(e) =>
                    setDividendForm((prev) => ({
                      ...prev,
                      periodStartDate: e.target.value,
                    }))
                  }
                />
              </div>

              <div className="form-group">
                <label htmlFor="periodEndDate">Interest Period End</label>
                <input
                  id="periodEndDate"
                  type="date"
                  required
                  value={dividendForm.periodEndDate}
                  onChange={(e) =>
                    setDividendForm((prev) => ({
                      ...prev,
                      periodEndDate: e.target.value,
                    }))
                  }
                />
              </div>

              <div className="form-group">
                <label htmlFor="distributionDate">Distribution Date</label>
                <input
                  id="distributionDate"
                  type="date"
                  value={dividendForm.distributionDate}
                  onChange={(e) =>
                    setDividendForm((prev) => ({
                      ...prev,
                      distributionDate: e.target.value,
                    }))
                  }
                />
              </div>

              <button
                type="submit"
                className="btn-primary"
                disabled={dividendActionLoading}
              >
                {dividendActionLoading ? "Creating..." : "Save Dividend"}
              </button>
            </form>
          </section>
        )}

        <section className="admin-card">
          {dividends.length === 0 ? (
            <p className="empty-state">No dividend distributions yet.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Financial Year</th>
                    <th>Pool</th>
                    <th>Status</th>
                    <th>Distribution Date</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {dividends.map((d) => (
                    <tr key={d._id}>
                      <td>{d.financialYear}</td>

                      <td>₦{Number(d.pool || 0).toLocaleString()}</td>

                      <td>
                        <span className={`status-badge ${d.status}`}>
                          {d.status}
                        </span>
                      </td>

                      <td>{d.distributionDate || "—"}</td>

                      <td className="actions-cell">
                        <button
                          className="view-btn"
                          onClick={() => openDividendDetail(d._id)}
                        >
                          View
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  const handleSecurityUnlock = (member) => {
    if (!member?._id || member.role === "admin") return;

    setActionModal({
      type: "security-unlock",
      member,
      title: "Unlock Security-Locked Account",
      description: `${member.fullName || member.email} reached the maximum number of failed authentication attempts. Unlocking will reset the security escalation and allow the member to sign in again.`,
      confirmText: "Unlock Account",
      danger: false,
    });
  };

  const handleBlockToggle = (member) => {
    const blocked = Boolean(member.isBlocked);
    setActionModal({
      type: blocked ? "unblock-member" : "block-member",
      member,
      title: blocked ? "Unblock Member Account" : "Block Member Account",
      description: blocked
        ? `Allow ${member.fullName || member.email} to access the website and mobile app again.`
        : `Block ${member.fullName || member.email} on both the website and mobile app.`,
      label: blocked ? "Reason (optional)" : "Reason",
      value: blocked ? "" : "Security review by administrator",
      placeholder: blocked
        ? "Optional reason"
        : "Why is this account being blocked?",
      inputType: "textarea",
      confirmText: blocked ? "Unblock Account" : "Block Account",
      danger: !blocked,
    });
  };

  /* ================================
     MEMBERS
  ================================= */

  const getMemberAccountStatus = (member) => {
    const temporaryLockActive =
      member.securityLockedUntil &&
      new Date(member.securityLockedUntil).getTime() > Date.now();

    if (member.securityLockedPermanently) return "security-locked";
    if (member.isBlocked) return "blocked";
    if (temporaryLockActive) return "security-locked";
    if (member.role === "admin") return "admin";
    if (member.membershipType === "interest-bearing") return "interest-bearing";
    if (member.membershipType === "interest-free") return "interest-free";
    return "active";
  };

  const filteredMembers = members.filter((member) => {
    const query = memberSearch.trim().toLowerCase();
    const status = getMemberAccountStatus(member);

    const matchesSearch =
      !query ||
      [
        member.fullName,
        member.email,
        member.phone,
        member.membershipType,
        member.role,
        status,
      ]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(query));

    const matchesFilter =
      memberFilter === "all" ||
      memberFilter === status ||
      (memberFilter === "active" && status === "active");

    return matchesSearch && matchesFilter;
  });

  const filteredApplications = applications.filter((application) => {
    const query = applicationSearch.trim().toLowerCase();

    const matchesSearch =
      !query ||
      [
        application.fullName,
        application.email,
        application.phone,
        application.membershipCategory,
        application.membershipType,
        application.status,
      ]
        .filter(Boolean)
        .some((value) => String(value).toLowerCase().includes(query));

    const matchesFilter =
      applicationFilter === "all" ||
      applicationFilter === application.status ||
      applicationFilter === application.membershipType;

    return matchesSearch && matchesFilter;
  });

  const renderMembers = () => {
    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Members</p>
            <h1>Members</h1>
            <p className="admin-subtitle">
              View cooperative members and their savings.
            </p>
          </div>

          <button
            type="button"
            className="admin-primary-btn"
            onClick={() => setShowAddExistingMember(true)}
          >
            + Add Member
          </button>
        </div>

        <section className="admin-card">
          <div className="admin-list-toolbar">
            <div className="admin-search-wrap">
              <span className="admin-search-icon">⌕</span>
              <input
                type="search"
                className="admin-search-input"
                placeholder="Search name, email, phone, role..."
                value={memberSearch}
                onChange={(e) => setMemberSearch(e.target.value)}
              />
              {memberSearch && (
                <button
                  type="button"
                  className="admin-search-clear"
                  onClick={() => setMemberSearch("")}
                  aria-label="Clear member search"
                >
                  ×
                </button>
              )}
            </div>

            <div
              className="admin-filter-group"
              role="group"
              aria-label="Member filters"
            >
              {[
                ["all", "All"],
                ["active", "Active"],
                ["blocked", "Blocked"],
                ["security-locked", "Security Locked"],
                ["admin", "Admin"],
                ["interest-bearing", "Interest-Bearing"],
                ["interest-free", "Interest-Free"],
              ].map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  className={`admin-filter-btn ${memberFilter === value ? "active" : ""}`}
                  onClick={() => setMemberFilter(value)}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="admin-results-count">
              Showing <strong>{filteredMembers.length}</strong> of{" "}
              <strong>{members.length}</strong> members
            </div>
          </div>

          {filteredMembers.length === 0 ? (
            <div className="admin-empty-search">
              <strong>No members found</strong>
              <span>Try a different search term or filter.</span>
            </div>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Membership Type</th>
                    <th>Savings Balance</th>
                    <th>Shareholding</th>
                    <th>Loan Eligibility</th>
                    <th>Account Setup</th>
                    <th>Account Status</th>
                    <th>Joined</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredMembers.map((m) => (
                    <tr key={m._id}>
                      <td>{m.fullName}</td>
                      <td>{m.email}</td>

                      <td>
                        <span
                          className={`status-badge ${
                            m.role === "admin" ? "approved" : "pending"
                          }`}
                        >
                          {m.role}
                        </span>
                      </td>

                      <td>
                        {m.membershipType ? (
                          <span className="loan-type-badge">
                            {m.membershipType === "interest-free"
                              ? "Interest-Free"
                              : "Interest-Bearing"}
                          </span>
                        ) : (
                          <span className="muted">—</span>
                        )}
                      </td>

                      <td>₦{Number(m.savingsBalance || 0).toLocaleString()}</td>

                      <td>
                        <div className="member-shareholding-cell">
                          <span>
                            ₦{Number(m.shareholding || 0).toLocaleString()}
                          </span>
                          <button
                            type="button"
                            className="admin-secondary-btn member-shareholding-btn"
                            onClick={() => handleShareholdingUpdate(m)}
                          >
                            Update
                          </button>
                        </div>
                      </td>

                      <td>
                        ₦{(Number(m.savingsBalance || 0) * 2).toLocaleString()}
                      </td>

                      <td>
                        <span
                          className={`status-badge ${m.mustChangePassword ? "pending" : "approved"}`}
                        >
                          {m.mustChangePassword ? "Password Pending" : "Ready"}
                        </span>
                      </td>

                      <td>
                        <span
                          className={`status-badge ${
                            m.securityLockedPermanently ||
                            m.isBlocked ||
                            m.securityLockedUntil
                              ? "rejected"
                              : "approved"
                          }`}
                        >
                          {m.securityLockedPermanently
                            ? "Security Locked"
                            : m.isBlocked
                              ? "Blocked"
                              : m.securityLockedUntil &&
                                  new Date(m.securityLockedUntil) > new Date()
                                ? `Locked · ${m.securityLockLevel === 1 ? "10 min" : "30 min"}`
                                : "Active"}
                        </span>
                      </td>

                      <td>{new Date(m.createdAt).toLocaleDateString()}</td>

                      <td className="actions-cell">
                        {m.role === "admin" ? (
                          <span className="muted">Protected</span>
                        ) : (
                          <div className="member-action-stack">
                            {m.securityLockedPermanently ? (
                              <button
                                type="button"
                                className="admin-secondary-btn"
                                onClick={() => handleSecurityUnlock(m)}
                                title={`Unlock security lock for ${m.fullName || "member"}`}
                              >
                                Unlock Account
                              </button>
                            ) : (
                              <button
                                type="button"
                                className={
                                  m.isBlocked
                                    ? "admin-secondary-btn"
                                    : "reject-btn"
                                }
                                onClick={() => handleBlockToggle(m)}
                                title={
                                  m.isBlocked
                                    ? `Unblock ${m.fullName || "member"}`
                                    : `Block ${m.fullName || "member"}`
                                }
                              >
                                {m.isBlocked
                                  ? "Unblock Account"
                                  : "Block Account"}
                              </button>
                            )}
                            <button
                              type="button"
                              className="reject-btn"
                              onClick={() => handleDeleteMember(m)}
                              disabled={deletingMemberId === m._id}
                              title={`Delete ${m.fullName || "member"}`}
                            >
                              <FaTrash />
                              {deletingMemberId === m._id
                                ? "Deleting..."
                                : "Delete Account"}
                            </button>
                          </div>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     MEMBERSHIP APPLICATIONS
  ================================= */

  const renderMembership = () => {
    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Membership</p>
            <h1>Membership Applications</h1>
            <p className="admin-subtitle">
              Review applications submitted by new members.
            </p>
          </div>
        </div>

        <section className="admin-card">
          <div className="admin-list-toolbar">
            <div className="admin-search-wrap">
              <span className="admin-search-icon">⌕</span>
              <input
                type="search"
                className="admin-search-input"
                placeholder="Search name, email, phone, category..."
                value={applicationSearch}
                onChange={(e) => setApplicationSearch(e.target.value)}
              />
              {applicationSearch && (
                <button
                  type="button"
                  className="admin-search-clear"
                  onClick={() => setApplicationSearch("")}
                  aria-label="Clear application search"
                >
                  ×
                </button>
              )}
            </div>

            <div
              className="admin-filter-group"
              role="group"
              aria-label="Application filters"
            >
              {[
                ["all", "All"],
                ["pending", "Pending"],
                ["approved", "Approved"],
                ["rejected", "Rejected"],
                ["interest-bearing", "Interest-Bearing"],
                ["interest-free", "Interest-Free"],
              ].map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  className={`admin-filter-btn ${applicationFilter === value ? "active" : ""}`}
                  onClick={() => setApplicationFilter(value)}
                >
                  {label}
                </button>
              ))}
            </div>

            <div className="admin-results-count">
              Showing <strong>{filteredApplications.length}</strong> of{" "}
              <strong>{applications.length}</strong> applications
            </div>
          </div>

          {filteredApplications.length === 0 ? (
            <div className="admin-empty-search">
              <strong>No applications found</strong>
              <span>Try a different search term or filter.</span>
            </div>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Applicant</th>
                    <th>Phone</th>
                    <th>Category</th>
                    <th>Type</th>
                    <th>Proposed Amount</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {filteredApplications.map((a) => (
                    <tr key={a._id}>
                      <td>
                        {a.fullName}
                        <br />
                        <span className="muted">{a.email}</span>
                      </td>

                      <td>{a.phone}</td>

                      <td>{a.membershipCategory}</td>

                      <td>
                        <span className="loan-type-badge">
                          {a.membershipType === "interest-free"
                            ? "Interest-Free"
                            : "Interest-Bearing"}
                        </span>
                      </td>

                      <td>₦{Number(a.proposedAmount || 0).toLocaleString()}</td>

                      <td>
                        <span className={`status-badge ${a.status}`}>
                          {a.status}
                        </span>
                      </td>

                      <td className="actions-cell">
                        <button
                          className="view-btn"
                          onClick={() => {
                            setOpenInEditMode(false);
                            setViewingApplication(a);
                          }}
                        >
                          View
                        </button>

                        <button
                          className="update-btn"
                          onClick={() => {
                            setOpenInEditMode(true);
                            setViewingApplication(a);
                          }}
                        >
                          Update
                        </button>

                        {a.status === "pending" && (
                          <>
                            <button
                              className="approve-btn"
                              onClick={() =>
                                handleApplicationStatus(a._id, "approved")
                              }
                            >
                              Approve
                            </button>

                            <button
                              className="reject-btn"
                              onClick={() =>
                                handleApplicationStatus(a._id, "rejected")
                              }
                            >
                              Reject
                            </button>
                          </>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     LOAN ELIGIBILITY APPLICATIONS
     (Full Loan Application: BVN + bio-data review)
  ================================= */

  const renderLoanEligibility = () => {
    const isReady = (item) =>
      item.status === "pending" &&
      item.providerVerificationStatus === "completed" &&
      item.bvnVerificationStatus === "verified" &&
      item.faceVerificationStatus === "verified";

    const counts = {
      review: loanEligibilityApplications.filter(isReady).length,
      progress: loanEligibilityApplications.filter(
        (item) => item.status === "draft",
      ).length,
      approved: loanEligibilityApplications.filter(
        (item) => item.status === "approved",
      ).length,
      rejected: loanEligibilityApplications.filter(
        (item) => item.status === "rejected",
      ).length,
      all: loanEligibilityApplications.length,
    };

    const tabs = [
      { key: "review", text: "Ready for review" },
      { key: "progress", text: "In progress" },
      { key: "approved", text: "Approved" },
      { key: "rejected", text: "Rejected" },
      { key: "all", text: "All" },
    ];

    const visible = loanEligibilityApplications.filter((item) => {
      if (eligibilityFilter === "review") return isReady(item);
      if (eligibilityFilter === "progress") return item.status === "draft";
      if (eligibilityFilter === "approved") return item.status === "approved";
      if (eligibilityFilter === "rejected") return item.status === "rejected";
      return true;
    });

    return (
      <>
        <div className="admin-page-heading full-loan-admin-heading">
          <div>
            <p className="eyebrow">Loans</p>
            <h1>Full Loan Applications</h1>
            <p className="admin-subtitle">
              Review each member's identity verification, compare it with their
              cooperative record, then approve or reject before they can request
              a loan.
            </p>
          </div>
          {counts.review > 0 && (
            <div className="full-loan-queue-pill">
              <strong>{counts.review}</strong>
              <span>Ready for review</span>
            </div>
          )}
        </div>

        <div className="kyc-filter-tabs" role="tablist">
          {tabs.map((tab) => (
            <button
              key={tab.key}
              type="button"
              role="tab"
              aria-selected={eligibilityFilter === tab.key}
              className={eligibilityFilter === tab.key ? "active" : ""}
              onClick={() => setEligibilityFilter(tab.key)}
            >
              {tab.text} <span>{counts[tab.key]}</span>
            </button>
          ))}
        </div>

        <section className="admin-card full-loan-admin-card">
          {visible.length === 0 ? (
            <div className="full-loan-admin-empty">
              <div className="full-loan-admin-empty-icon">✓</div>
              <strong>
                {eligibilityFilter === "review"
                  ? "Nothing waiting for review"
                  : "No applications here"}
              </strong>
              <span>
                Completed member verifications will appear here automatically.
              </span>
            </div>
          ) : (
            <div className="admin-table-wrap full-loan-table-wrap">
              <table className="admin-table full-loan-admin-table">
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Verification</th>
                    <th>Identity match</th>
                    <th>Liveness</th>
                    <th>Status</th>
                    <th>Submitted</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((application) => {
                    const finished =
                      application.providerVerificationStatus === "completed";
                    const matched =
                      application.identityMatchStatus === "matched";
                    const mismatch =
                      application.identityMatchStatus === "mismatch";

                    return (
                      <tr key={application._id}>
                        <td>
                          <strong>{application.user?.fullName || "—"}</strong>
                          <br />
                          <span className="muted">
                            {application.user?.email || "—"}
                          </span>
                        </td>
                        <td>
                          <span
                            className={`verification-mini ${finished ? "verified" : "pending"}`}
                          >
                            {finished ? "Completed" : "In progress"}
                          </span>
                          <br />
                          <span className="muted">
                            {statusLabel(
                              application.providerVerificationStatus,
                            )}
                          </span>
                        </td>
                        <td>
                          <span
                            className={
                              matched
                                ? "verification-text-ok"
                                : mismatch
                                  ? "verification-text-bad"
                                  : "verification-text-pending"
                            }
                          >
                            {mismatch
                              ? "Needs checking"
                              : statusLabel(application.identityMatchStatus)}
                          </span>
                          {application.bvnLast4 && (
                            <>
                              <br />
                              <span className="muted">
                                BVN •••••••{application.bvnLast4}
                              </span>
                            </>
                          )}
                        </td>
                        <td>
                          <span
                            className={
                              application.faceVerificationStatus === "verified"
                                ? "verification-text-ok"
                                : "verification-text-pending"
                            }
                          >
                            {statusLabel(application.faceVerificationStatus)}
                          </span>
                        </td>
                        <td>
                          <span
                            className={`status-badge ${application.status}`}
                          >
                            {application.status === "draft"
                              ? "In progress"
                              : application.status}
                          </span>
                        </td>
                        <td>
                          {application.submittedDate
                            ? new Date(
                                application.submittedDate,
                              ).toLocaleDateString()
                            : "—"}
                        </td>
                        <td className="actions-cell full-loan-actions-cell">
                          <button
                            className={
                              application.status === "pending"
                                ? "approve-btn"
                                : "view-btn"
                            }
                            onClick={() =>
                              setReviewEligibilityId(application._id)
                            }
                          >
                            {application.status === "pending"
                              ? "Review"
                              : "View"}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     LOANS
  ================================= */

  const renderLoansManagement = () => {
    const activeLoans = loans.filter((loan) =>
      ["approved", "disbursed", "active"].includes(
        String(loan.status).toLowerCase(),
      ),
    );
    const totalDisbursed = loans.reduce(
      (sum, loan) =>
        sum +
        (["approved", "disbursed", "active"].includes(
          String(loan.status).toLowerCase(),
        )
          ? Number(loan.amount || 0)
          : 0),
      0,
    );
    const outstanding = loans.reduce(
      (sum, loan) => sum + Number(loan.outstandingBalance || 0),
      0,
    );

    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Loans</p>
            <h1>Loans</h1>
            <p className="admin-subtitle">
              Monitor approved, disbursed, and active cooperative loans.
            </p>
          </div>
          <button type="button" className="btn-secondary" onClick={loadLoans}>
            Refresh
          </button>
        </div>

        <div className="admin-stat-grid">
          <div className="admin-stat-card">
            <div>
              <span>Active Loans</span>
              <strong>{activeLoans.length}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Total Disbursed</span>
              <strong>₦{totalDisbursed.toLocaleString()}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Outstanding</span>
              <strong>₦{outstanding.toLocaleString()}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Total Loan Records</span>
              <strong>{loans.length}</strong>
            </div>
          </div>
        </div>

        <section className="admin-card">
          {loans.length === 0 ? (
            <p className="empty-state">No loan records found.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Member</th>
                    <th>Type</th>
                    <th>Amount</th>
                    <th>Outstanding</th>
                    <th>Term</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  {loans.map((loan) => (
                    <tr key={loan._id}>
                      <td>
                        <strong>{loan.user?.fullName || "—"}</strong>
                        <br />
                        <span className="muted">{loan.user?.email || "—"}</span>
                      </td>
                      <td>
                        <span className="loan-type-badge">
                          {loan.loanType || "—"}
                        </span>
                      </td>
                      <td>₦{Number(loan.amount || 0).toLocaleString()}</td>
                      <td>
                        ₦{Number(loan.outstandingBalance || 0).toLocaleString()}
                      </td>
                      <td>
                        {loan.termMonths ? `${loan.termMonths} months` : "—"}
                      </td>
                      <td>
                        <span className={`status-badge ${loan.status}`}>
                          {loan.status || "—"}
                        </span>
                      </td>
                      <td>
                        {loan.applicationDate
                          ? new Date(loan.applicationDate).toLocaleDateString()
                          : "—"}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     TRANSACTIONS
  ================================= */

  const renderTransactions = () => {
    const transactions = [
      ...requests.map((item) => ({
        id: `s-${item._id}`,
        date: item.createdAt,
        member: item.user?.fullName || "—",
        type: "Savings",
        direction: "Money In",
        amount: Number(item.amount || 0),
        status: item.status,
        reference: item.reference || item._id,
      })),
      ...loanRepayments.map((item) => ({
        id: `r-${item._id}`,
        date: item.createdAt,
        member: item.user?.fullName || "—",
        type: "Loan Repayment",
        direction: "Money In",
        amount: Number(item.amount || 0),
        status: item.status,
        reference: item.reference || item._id,
      })),
      ...loans
        .filter((item) =>
          ["disbursed", "active"].includes(String(item.status).toLowerCase()),
        )
        .map((item) => ({
          id: `l-${item._id}`,
          date: item.disbursementDate || item.applicationDate || item.createdAt,
          member: item.user?.fullName || "—",
          type: "Loan Disbursement",
          direction: "Money Out",
          amount: Number(item.amount || 0),
          status: item.status,
          reference: item.reference || item._id,
        })),
    ].sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));

    const moneyIn = transactions
      .filter(
        (item) => item.direction === "Money In" && item.status === "approved",
      )
      .reduce((sum, item) => sum + item.amount, 0);

    const moneyOut = transactions
      .filter(
        (item) => item.direction === "Money Out" && item.status !== "rejected",
      )
      .reduce((sum, item) => sum + item.amount, 0);

    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Finance</p>
            <h1>Transactions</h1>
            <p className="admin-subtitle">
              View financial activity recorded in the cooperative system.
            </p>
          </div>
          <button
            type="button"
            className="btn-secondary"
            onClick={() =>
              Promise.all([loadRequests(), loadLoanRepayments(), loadLoans()])
            }
          >
            Refresh
          </button>
        </div>

        <div className="admin-stat-grid">
          <div className="admin-stat-card">
            <div>
              <span>Money In</span>
              <strong>₦{moneyIn.toLocaleString()}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Money Out</span>
              <strong>₦{moneyOut.toLocaleString()}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Transactions</span>
              <strong>{transactions.length}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Net Movement</span>
              <strong>₦{(moneyIn - moneyOut).toLocaleString()}</strong>
            </div>
          </div>
        </div>

        <section className="admin-card">
          {transactions.length === 0 ? (
            <p className="empty-state">No transactions found.</p>
          ) : (
            <div className="admin-table-wrap">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Date</th>
                    <th>Member</th>
                    <th>Type</th>
                    <th>Reference</th>
                    <th>Direction</th>
                    <th>Amount</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((transaction) => (
                    <tr key={transaction.id}>
                      <td>
                        {transaction.date
                          ? new Date(transaction.date).toLocaleDateString()
                          : "—"}
                      </td>
                      <td>{transaction.member}</td>
                      <td>{transaction.type}</td>
                      <td>{transaction.reference}</td>
                      <td>{transaction.direction}</td>
                      <td>₦{transaction.amount.toLocaleString()}</td>
                      <td>
                        <span className={`status-badge ${transaction.status}`}>
                          {transaction.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </>
    );
  };

  /* ================================
     REPORTS
  ================================= */

  const renderReports = () => {
    const approvedMembers = members.filter((member) => member.role !== "admin");
    const totalSavingsReport = approvedMembers.reduce(
      (sum, member) => sum + Number(member.savingsBalance || 0),
      0,
    );
    const totalLoanAmount = loans.reduce(
      (sum, loan) => sum + Number(loan.amount || 0),
      0,
    );
    const totalOutstanding = loans.reduce(
      (sum, loan) => sum + Number(loan.outstandingBalance || 0),
      0,
    );
    const totalRepayments = loanRepayments
      .filter((item) => item.status === "approved")
      .reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const totalDividendPaid = dividends.reduce(
      (sum, item) => sum + Number(item.paidAmount || 0),
      0,
    );

    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Reports</p>
            <h1>Reports</h1>
            <p className="admin-subtitle">
              Financial and membership summaries based on current records.
            </p>
          </div>
          <button
            type="button"
            className="btn-secondary"
            onClick={() =>
              Promise.all([
                loadMembers(),
                loadLoans(),
                loadLoanRepayments(),
                loadDividends(),
                loadRequests(),
              ])
            }
          >
            Refresh Data
          </button>
        </div>

        <div className="admin-stat-grid">
          <div className="admin-stat-card">
            <div>
              <span>Members</span>
              <strong>{approvedMembers.length}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Total Savings</span>
              <strong>₦{totalSavingsReport.toLocaleString()}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Total Loans</span>
              <strong>₦{totalLoanAmount.toLocaleString()}</strong>
            </div>
          </div>
          <div className="admin-stat-card">
            <div>
              <span>Outstanding Loans</span>
              <strong>₦{totalOutstanding.toLocaleString()}</strong>
            </div>
          </div>
        </div>

        <section className="admin-card">
          <div className="admin-card-header">
            <div>
              <p className="eyebrow">Financial Summary</p>
              <h2>Cooperative Report</h2>
            </div>
          </div>

          <div className="admin-mini-stat">
            <span>Approved Repayments</span>
            <strong>₦{totalRepayments.toLocaleString()}</strong>
          </div>
          <div className="admin-mini-stat">
            <span>Dividend Records</span>
            <strong>{dividends.length}</strong>
          </div>
          <div className="admin-mini-stat">
            <span>Recorded Dividend Paid Amount</span>
            <strong>₦{totalDividendPaid.toLocaleString()}</strong>
          </div>
          <div className="admin-mini-stat">
            <span>Membership Applications</span>
            <strong>{applications.length}</strong>
          </div>
          <div className="admin-mini-stat">
            <span>Loan Applications</span>
            <strong>{loans.length}</strong>
          </div>
        </section>
      </>
    );
  };

  /* ================================
     SETTINGS
  ================================= */

  /* ================================
     SETTINGS: ACCOUNT DETAILS + PASSWORD
  ================================= */

  const [settingsName, setSettingsName] = useState(user?.fullName || "");
  const [savingName, setSavingName] = useState(false);
  const [nameMessage, setNameMessage] = useState(null); // { type: "success" | "error", text }
  // Tracks the value settingsName was last synced from, so a fresh user.fullName
  // (e.g. after refreshUser()) updates the field without fighting active typing.
  const [syncedFullName, setSyncedFullName] = useState(user?.fullName || "");

  if (user?.fullName !== undefined && user.fullName !== syncedFullName) {
    setSyncedFullName(user.fullName);
    setSettingsName(user.fullName);
  }

  const saveAdminName = async (event) => {
    event.preventDefault();
    const trimmed = settingsName.trim();

    if (!trimmed) {
      setNameMessage({ type: "error", text: "Name cannot be empty." });
      return;
    }

    setSavingName(true);
    setNameMessage(null);

    try {
      await request("/users/me", {
        method: "PATCH",
        token: user.token,
        body: { fullName: trimmed },
      });
      await refreshUser();
      setNameMessage({ type: "success", text: "Your name has been updated." });
    } catch (err) {
      setNameMessage({ type: "error", text: err.message });
    } finally {
      setSavingName(false);
    }
  };

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  });
  const [showPasswords, setShowPasswords] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [passwordMessage, setPasswordMessage] = useState(null);

  const passwordChecks = getPasswordChecks(passwordForm.newPassword);
  const newPasswordStrong = isStrongPassword(passwordForm.newPassword);

  const savePassword = async (event) => {
    event.preventDefault();
    setPasswordMessage(null);

    if (!passwordForm.currentPassword) {
      setPasswordMessage({
        type: "error",
        text: "Enter your current password.",
      });
      return;
    }
    if (!newPasswordStrong) {
      setPasswordMessage({
        type: "error",
        text: "Your new password must be at least 8 characters and include uppercase and lowercase letters, a number, and a special character.",
      });
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      setPasswordMessage({
        type: "error",
        text: "New passwords do not match.",
      });
      return;
    }

    setSavingPassword(true);

    try {
      await request("/users/me/password", {
        method: "PATCH",
        token: user.token,
        body: {
          currentPassword: passwordForm.currentPassword,
          newPassword: passwordForm.newPassword,
        },
      });
      setPasswordMessage({
        type: "success",
        text: "Your password has been updated.",
      });
      setPasswordForm({
        currentPassword: "",
        newPassword: "",
        confirmPassword: "",
      });
    } catch (err) {
      setPasswordMessage({ type: "error", text: err.message });
    } finally {
      setSavingPassword(false);
    }
  };

  const renderSettings = () => {
    return (
      <>
        <div className="admin-page-heading">
          <div>
            <p className="eyebrow">Administration</p>
            <h1>Settings</h1>
            <p className="admin-subtitle">
              Manage your administrator account and see the cooperative's
              current configuration.
            </p>
          </div>
        </div>

        {/* ACCOUNT INFORMATION — name is editable, email/role are fixed */}
        <section className="admin-card">
          <div className="admin-card-header">
            <div>
              <p className="eyebrow">Administrator</p>
              <h2>Account Information</h2>
            </div>
          </div>

          <form className="admin-settings-form" onSubmit={saveAdminName}>
            {nameMessage && (
              <div
                className={
                  nameMessage.type === "error" ? "form-error" : "form-success"
                }
              >
                {nameMessage.text}
              </div>
            )}

            <div className="admin-form-grid">
              <label>
                Full name
                <input
                  type="text"
                  value={settingsName}
                  onChange={(e) => setSettingsName(e.target.value)}
                  placeholder="Your full name"
                  disabled={savingName}
                />
              </label>

              <label>
                Email address
                <input type="email" value={user?.email || ""} disabled />
              </label>
            </div>

            <div className="admin-mini-stat">
              <span>Role</span>
              <strong style={{ textTransform: "capitalize" }}>
                {user?.role || "Administrator"}
              </strong>
            </div>

            <button
              type="submit"
              className="update-btn"
              disabled={
                savingName || settingsName.trim() === (user?.fullName || "")
              }
              style={{ marginTop: 16 }}
            >
              {savingName ? "Saving…" : "Save name"}
            </button>
          </form>

          <p className="admin-settings-footnote">
            Your email address identifies your admin account and can't be
            changed here. Contact another administrator if it needs updating.
          </p>
        </section>

        {/* CHANGE PASSWORD */}
        <section className="admin-card">
          <div className="admin-card-header">
            <div>
              <p className="eyebrow">Security</p>
              <h2>Change Password</h2>
            </div>
          </div>

          <form className="admin-settings-form" onSubmit={savePassword}>
            {passwordMessage && (
              <div
                className={
                  passwordMessage.type === "error"
                    ? "form-error"
                    : "form-success"
                }
              >
                {passwordMessage.text}
              </div>
            )}

            <div className="admin-form-grid">
              <label className="admin-form-full">
                Current password
                <input
                  type={showPasswords ? "text" : "password"}
                  value={passwordForm.currentPassword}
                  onChange={(e) =>
                    setPasswordForm((prev) => ({
                      ...prev,
                      currentPassword: e.target.value,
                    }))
                  }
                  autoComplete="current-password"
                  disabled={savingPassword}
                />
              </label>

              <label>
                New password
                <input
                  type={showPasswords ? "text" : "password"}
                  value={passwordForm.newPassword}
                  onChange={(e) =>
                    setPasswordForm((prev) => ({
                      ...prev,
                      newPassword: e.target.value,
                    }))
                  }
                  autoComplete="new-password"
                  disabled={savingPassword}
                />
              </label>

              <label>
                Confirm new password
                <input
                  type={showPasswords ? "text" : "password"}
                  value={passwordForm.confirmPassword}
                  onChange={(e) =>
                    setPasswordForm((prev) => ({
                      ...prev,
                      confirmPassword: e.target.value,
                    }))
                  }
                  autoComplete="new-password"
                  disabled={savingPassword}
                />
              </label>
            </div>

            <label className="admin-settings-checkbox">
              <input
                type="checkbox"
                checked={showPasswords}
                onChange={(e) => setShowPasswords(e.target.checked)}
              />
              Show passwords
            </label>

            {passwordForm.newPassword && (
              <ul className="admin-password-checklist">
                <li className={passwordChecks.length ? "met" : ""}>
                  At least 8 characters
                </li>
                <li className={passwordChecks.upperLower ? "met" : ""}>
                  Uppercase and lowercase letters
                </li>
                <li className={passwordChecks.number ? "met" : ""}>A number</li>
                <li className={passwordChecks.special ? "met" : ""}>
                  A special character
                </li>
              </ul>
            )}

            <button
              type="submit"
              className="update-btn"
              disabled={savingPassword}
              style={{ marginTop: 4 }}
            >
              {savingPassword ? "Saving…" : "Update password"}
            </button>
          </form>
        </section>

        {/* COOPERATIVE CONFIGURATION */}
        <section className="admin-card">
          <div className="admin-card-header">
            <div>
              <p className="eyebrow">Cooperative</p>
              <h2>Cooperative Configuration</h2>
            </div>
          </div>

          {cooperativeSettingsMessage && (
            <div
              className={
                cooperativeSettingsMessage.type === "error"
                  ? "form-error"
                  : "form-success"
              }
            >
              {cooperativeSettingsMessage.text}
            </div>
          )}

          <div className="admin-settings-note">
            <strong>Manage the live cooperative settings</strong>
            <p>
              These values are used by the loan eligibility and repayment
              screens across the website and mobile app.
            </p>
          </div>

          <form
            className="admin-settings-form"
            onSubmit={saveCooperativeSettings}
          >
            <div className="admin-form-grid">
              <label>
                Loan eligibility multiplier
                <input
                  type="number"
                  min="0.01"
                  max="2"
                  step="0.01"
                  value={cooperativeSettings.loanMultiplier}
                  onChange={(e) =>
                    setCooperativeSettings((prev) => ({
                      ...prev,
                      loanMultiplier: e.target.value,
                    }))
                  }
                  disabled={savingCooperativeSettings}
                />
                <span className="admin-settings-footnote">
                  Maximum allowed: 2× current savings balance.
                </span>
              </label>

              <label>
                Repayment account name
                <input
                  type="text"
                  value={cooperativeSettings.repaymentAccountName}
                  onChange={(e) =>
                    setCooperativeSettings((prev) => ({
                      ...prev,
                      repaymentAccountName: e.target.value,
                    }))
                  }
                  disabled={savingCooperativeSettings}
                />
              </label>

              <label>
                Repayment bank
                <input
                  type="text"
                  value={cooperativeSettings.repaymentBank}
                  onChange={(e) =>
                    setCooperativeSettings((prev) => ({
                      ...prev,
                      repaymentBank: e.target.value,
                    }))
                  }
                  disabled={savingCooperativeSettings}
                />
              </label>

              <label>
                Repayment account number
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={10}
                  value={cooperativeSettings.repaymentAccountNumber}
                  onChange={(e) =>
                    setCooperativeSettings((prev) => ({
                      ...prev,
                      repaymentAccountNumber: e.target.value.replace(/\D/g, ""),
                    }))
                  }
                  disabled={savingCooperativeSettings}
                />
              </label>
            </div>

            <button
              type="submit"
              className="update-btn"
              disabled={savingCooperativeSettings}
            >
              {savingCooperativeSettings ? "Saving…" : "Save configuration"}
            </button>
          </form>
        </section>
      </>
    );
  };

  /* ================================
     SELECT CONTENT
  ================================= */

  const renderContent = () => {
    switch (activeSection) {
      case "overview":
        return renderOverview();

      case "members":
        return renderMembers();

      case "membership":
        return renderMembership();

      case "savings":
        return renderSavings();

      case "loans":
        return renderLoansManagement();

      case "loan-eligibility":
        return renderLoanEligibility();

      case "loan-requests":
        return renderLoans();

      case "repayments":
        return renderRepayments();

      case "dividends":
        return renderDividends();

      case "transactions":
        return renderTransactions();

      case "withdrawals":
        return renderWithdrawals();

      case "reports":
        return renderReports();

      case "settings":
        return renderSettings();

      case "gallery":
        return <GalleryManagement token={user.token} />;

      default:
        return renderOverview();
    }
  };

  return (
    <div className="admin-layout">
      <AdminSidebar
        activeSection={activeSection}
        onNavigate={setActiveSection}
        onLogout={logout}
      />

      <main className="admin-main">
        <header className="admin-topbar">
          <div>
            <p className="admin-topbar-label">Exclusive Cooperative</p>
            <h2>Administration</h2>
          </div>

          <div className="admin-topbar-actions">
            <AdminNotifications
              applications={applications}
              requests={requests}
              loans={loans}
              loanEligibilityApplications={loanEligibilityApplications}
              loanRepayments={loanRepayments}
              withdrawals={withdrawals}
              securityAlerts={securityAlerts}
              onNavigate={setActiveSection}
            />

            <div className="admin-user">
              <div className="admin-user-avatar">
                {user?.fullName?.charAt(0)?.toUpperCase() || "A"}
              </div>

              <div className="admin-user-info">
                <strong>{user?.fullName}</strong>
                <span>Administrator</span>
              </div>
            </div>
          </div>
        </header>

        <div className="admin-content">
          {error && <div className="form-error admin-error">{error}</div>}

          {loading && <div className="admin-loading">Loading...</div>}

          {!loading && renderContent()}
        </div>
      </main>

      {reviewEligibilityId && (
        <KycReviewModal
          key={reviewEligibilityId}
          applicationId={reviewEligibilityId}
          token={user.token}
          onClose={() => setReviewEligibilityId(null)}
          onDone={loadLoanEligibilityApplications}
        />
      )}

      {actionModal && (
        <AdminActionModal
          open
          title={actionModal.title}
          description={actionModal.description}
          label={actionModal.label}
          value={actionModal.value}
          placeholder={actionModal.placeholder}
          inputType={actionModal.inputType}
          confirmText={actionModal.confirmText}
          danger={actionModal.danger}
          loading={actionModalLoading}
          onClose={() => {
            if (!actionModalLoading) setActionModal(null);
          }}
          onSubmit={handleActionModalSubmit}
        />
      )}

      <AddExistingMemberModal
        open={showAddExistingMember}
        onClose={() => setShowAddExistingMember(false)}
        onCreate={handleCreateExistingMember}
      />

      {viewingApplication && (
        <MembershipModal
          application={viewingApplication}
          startInEditMode={openInEditMode}
          onClose={() => setViewingApplication(null)}
          onSave={handleApplicationSave}
          onStatusChange={handleApplicationStatus}
        />
      )}
    </div>
  );
}

export default AdminDashboard;
